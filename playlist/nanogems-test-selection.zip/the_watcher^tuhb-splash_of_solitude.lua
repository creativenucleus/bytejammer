c=0TIC=load'cls()for t=0,2e4 do e=math.cos(t+c)/300/((t+c/2)%1.4)a=math.tan(t*t)+c rect(120+math.cos(a)/e*2,120+math.sin(a)/e+math.sin(e/5)*120,1+a%2,1+a%2,10)c=1e-7+c end'
-- <WAVES>
-- 000:00000000ffffffff00000000ffffffff
-- 001:0123456789abcdeffedcba9876543210
-- 002:0123456789abcdef0123456789abcdef
-- </WAVES>

-- <PALETTE>
-- 000:1a1c2c5d275db13e53ef7d57ffcd75a7f07038b76425717929366f3b5dc941a6f673eff7f4f4f494b0c2566c86333c57
-- </PALETTE>

