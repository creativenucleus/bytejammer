TIC=load'for m=0,136 do for o=-120,120 do n=time()/608+o*(.05-(m>111 and(m-111)*.001or 0))a=n%2<1or math.random(136)<m and n/2%8+1pix(o+120,m,a)end end'
-- <WAVES>
-- 000:00000000ffffffff00000000ffffffff
-- 001:0123456789abcdeffedcba9876543210
-- 002:0123456789abcdef0123456789abcdef
-- </WAVES>

-- <PALETTE>
-- 000:1a1c2c5d275db13e53ef7d57ffcd75a7f07038b76425717929366f3b5dc941a6f673eff7f4f4f494b0c2566c86333c57
-- </PALETTE>

