TIC=load'o=o+.1	for	e=0,16319	do	d=-1r=e/16319+math.cos(o)/6-.6n=e%120/60-1	for	a=0,11	do	d=d-(n*d%2-1)^2-((d-o)%2-1)^2+.3	end	poke(e,r*d*9%3-d*r-2)end'o=0
-- <WAVES>
-- 000:00000000ffffffff00000000ffffffff
-- 001:0123456789abcdeffedcba9876543210
-- 002:0123456789abcdef0123456789abcdef
-- </WAVES>

-- <PALETTE>
-- 000:1a1c2c5d275db13e53ef7d57ffcd75a7f07038b76425717929366f3b5dc941a6f673eff7f4f4f494b0c2566c86333c57
-- </PALETTE>

